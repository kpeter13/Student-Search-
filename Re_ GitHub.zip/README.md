# Project Description

Developing a Web App that:

As a recruiter, I can select a student's profile to review from a search list.​
As a recruiter, I can click on button in the search results to preview their profile. ​
As a recruiter, I can see the GPA of students.​
As a recruiter, I can easily navigate back to the search results after reviewing a student's profile without losing my place in the list​.
As a recruiter, I can see if a student has a job.  